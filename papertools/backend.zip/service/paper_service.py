# backend/controllers/paper_controller.py
from flask import current_app, request,jsonify
from werkzeug.utils import secure_filename  # 新版本正确导入方式
from dao.paper_dao import PaperDao
from backend.models.operation import Operation
from backend.models.paper import Paper
from backend.config.database import db
from config.logging_config import logger
import re
import jieba
from collections import Counter
import requests
import math
from bs4 import BeautifulSoup
import requests  # 添加这行
import os
import uuid
import time
import io
import base64  # 需要安装: pip install textract
import random
from urllib.parse import quote, urlencode
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
class PaperService:
    def __init__(self):
        self.paper_dao = PaperDao()
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8'
        }
        # 复用浏览器实例（关键优化）
        self.driver = self._init_browser()

    #---------------------------------------------------------------------------
    def _init_browser(self):
        """初始化浏览器实例（增强反爬配置）"""
        chrome_options = Options()
        chrome_options.add_argument('--headless=new')
        chrome_options.add_argument('--disable-gpu')
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-blink-features=AutomationControlled')
        chrome_options.add_experimental_option('excludeSwitches', ['enable-automation'])
        chrome_options.add_experimental_option('useAutomationExtension', False)
        
        # 关键反爬选项（欺骗WebDriver特征）
        chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
        chrome_options.add_experimental_option('useAutomationExtension', False)
        chrome_options.add_argument("--disable-blink-features=AutomationControlled")
        chrome_options.add_argument(f"user-agent={self.headers['User-Agent']}")
        
        # 注入JavaScript隐藏WebDriver特征
        chrome_options.add_experimental_option("detach", True)  # 保持浏览器窗口打开（调试用）
        
        service = Service(ChromeDriverManager().install())
        driver = webdriver.Chrome(service=service, options=chrome_options)
        
        # 执行CDP命令完全隐藏自动化特征
        driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
            "source": """
            Object.defineProperty(navigator, 'webdriver', {
                get: () => undefined
            })
            window.navigator.chrome = {
                runtime: {},
                // 避免检测
                platform: window.navigator.platform
            }
            Object.defineProperty(navigator, 'languages', {
                get: () => ['zh-CN', 'zh']
            })
            Object.defineProperty(navigator, 'plugins', {
                get: () => [1, 2, 3, 4, 5]
            })
            """
        })
        
        driver.maximize_window()
        driver.set_page_load_timeout(30)  # 延长超时时间适应维普网
        return driver
    def __del__(self):
        """类销毁时关闭浏览器"""
        if hasattr(self, 'driver'):
            self.driver.quit()
### 辅助函数：主题关键词提取
    def extract_keywords(self, text, top_n=5):
        """优化关键词提取（增强中文支持）"""
        logger.info("begin extract_keywords")
        # 去除标点符号和特殊字符（保留中文标点）
        text = re.sub(r'[^\u4e00-\u9fa5a-zA-Z0-9\uff00-\uffff]', ' ', text)
        # 分词
        words = jieba.cut(text)
        # 过滤停用词（扩展中文停用词）
        stop_words = set([
            '的', '了', '在', '是', '我', '有', '和', '就', '不', '人', '都', '一', '一个', 
            '上', '也', '很', '到', '说', '要', '去', '你', '会', '着', '没有', '看', '好', 
            '自己', '这个', '那个', '然后', '如果', '所以', '但是', '因为', '或者', '而且'
        ])
        filtered_words = [word for word in words if word and word not in stop_words and len(word) > 1]
        # 统计词频并取前n个
        word_counts = Counter(filtered_words)
        logger.info("end extract_keywords")
        
        # 确保关键词为中文（维普网主要收录中文文献）
        return [word for word, _ in word_counts.most_common(top_n) if re.search(r'[\u4e00-\u9fa5]', word)]
        ### 优化版并发爬取方法（使用维普网）
    def crawl_multiple_articles(self, keywords, num_articles=5):
        """同步爬取多篇维普网相似文章（优化版）"""
        articles = []
        for _ in range(num_articles):
            article = self.crawl_similar_article_vip(keywords)
            if article:
                articles.append(article)
            # 每成功获取一篇文章后随机延迟（避免频繁请求）
            if article:
                time.sleep(random.uniform(4, 8))
        return articles
        
    
    ### 维普网爬取方法
    def crawl_similar_article_vip(self, keywords):
        """使用维普网爬取相似文章"""
        try:
            # 过滤并编码关键词（支持中文）
            valid_keywords = [kw for kw in keywords if isinstance(kw, str) and kw.strip()]
            if not valid_keywords:
                logger.warning("关键词列表为空或无效，无法爬取")
                return None
                
            search_query = ' '.join(valid_keywords)
            url = f'http://qikan.cqvip.com/Qikan/Article/Index?keyword={quote(search_query)}'
            logger.info(f"爬取维普网URL: {url}")
            
            # 增强反爬延迟（维普网反爬较严格）
            wait_time = random.uniform(5, 10)
            logger.info(f"等待{wait_time:.2f}秒后发送请求")
            time.sleep(wait_time)
            
            # 使用复用的浏览器实例
            self.driver.get(url)
            
            # 等待搜索结果加载（维普网需要更长时间）
            logger.info("等待维普网搜索结果加载...")
            WebDriverWait(self.driver, 20).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, 'div.ResultItem'))
            )
            
            # 滚动页面加载更多内容（维普网可能需要多次滚动）
            for _ in range(3):
                self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
                time.sleep(random.uniform(1, 2))
            
            # 保存页面源代码
            page_source = self.driver.page_source
            
            # 使用BeautifulSoup解析
            soup = BeautifulSoup(page_source, 'html.parser')
            
            # 提取文章信息（维普网选择器）
            article = self._extract_vip_article(soup)
            if not article:
                logger.warning("解析维普网页面后未找到文章信息")
                return None
                
            logger.info(f"找到维普网文章: {article['title']}")
            
            # 爬取文章详情页
            if article['url']:
                logger.info(f"请求维普网文章详情: {article['url']}")
                time.sleep(random.uniform(3, 5))  # 更长的延迟避免反爬
                self.driver.get(article['url'])
                
                try:
                    # 等待摘要元素加载
                    WebDriverWait(self.driver, 15).until(
                        EC.presence_of_element_located((By.CSS_SELECTOR, 'div.abstract'))
                    )
                    
                    # 提取内容
                    abstract_elem = self.driver.find_element(By.CSS_SELECTOR, 'div.abstract')
                    content = abstract_elem.text.strip() if abstract_elem else "无法提取内容"
                    
                    article['content'] = content
                    logger.info(f"成功提取维普网文章内容，长度: {len(content)}")
                    
                except Exception as e:
                    logger.error(f"提取维普网文章内容出错: {str(e)}")
                    article['content'] = "无法提取维普网文章内容"
                    
            return article
            
        except Exception as e:
            logger.error(f"维普网爬取出错: {str(e)}", exc_info=True)
            return None

    def _extract_vip_article(self, soup):
        """从维普网页面提取文章信息"""
        # 维普网搜索结果选择器
        result_items = soup.select('div.ResultItem')
        if not result_items:
            result_items = soup.select('li.article-item')
        
        if not result_items:
            return None
            
        first_item = result_items[0]
        title_elem = first_item.select_one('h2.title a')
        if not title_elem:
            title_elem = first_item.select_one('div.article-title a')
        
        if title_elem:
            title = title_elem.get_text(strip=True)
            url = title_elem.get('href', '')
            
            # 处理相对URL
            if url.startswith('/') and not url.startswith('http'):
                url = 'http://qikan.cqvip.com' + url
                
            return {
                'title': title,
                'url': url
            }
            
        return None

    def _fetch_article_content(self, article, chrome_options):
        """获取文章详情页内容"""
        if not article.get('url'):
            article['content'] = "未找到文章链接"
            return article
            
        try:
            driver = webdriver.Chrome(options=chrome_options)
            driver.get(article['url'])
            WebDriverWait(driver, 30).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, 'div.abstract_wr'))
            )
            
            # 提取内容
            abstract_elem = driver.find_element(By.CSS_SELECTOR, 'div.abstract_wr')
            content = abstract_elem.text.strip() if abstract_elem else "无法提取内容"
            
            driver.quit()
            article['content'] = content
            return article
            
        except Exception as e:
            logger.error(f"提取文章内容出错: {str(e)}")
            article['content'] = "无法提取文章具体内容"
            return article


    ### 辅助函数：文本预处理
    def preprocess_text(self, text):
        """优化文本预处理（增加对英文的支持）"""
        if not text:
            return []
        
        # 去除标点符号和特殊字符（支持中英文）
        text = re.sub(r'[^\u4e00-\u9fa5a-zA-Z0-9\s]', ' ', text)
        # 分词（支持中英文混合）
        words = jieba.cut(text)
        # 过滤停用词（扩展停用词表）
        stop_words = set([
            '的', '了', '在', '是', '我', '有', '和', '就', '不', '人', '都', '一', '一个', 
            '上', '也', '很', '到', '说', '要', '去', '你', '会', '着', '没有', '看', '好', 
            '自己', 'a', 'an', 'the', 'in', 'on', 'at', 'by', 'for', 'to', 'of', 'with', 'is',
            'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'having'
        ])
        return [word for word in words if word and word not in stop_words and len(word) > 1]
    ### 辅助函数：计算文本相似度（余弦相似度）
    def calculate_similarity(self,text1, text2):
        """使用余弦相似度计算两篇文章的相似度"""
        if not text1 or not text2:
            return 0.0
        
        # 合并所有词，创建词袋
        all_words = list(set(text1 + text2))
        
        # 生成词频向量
        def get_word_vector(words):
            vector = []
            for word in all_words:
                vector.append(words.count(word))
            return vector
        
        vec1 = get_word_vector(text1)
        vec2 = get_word_vector(text2)
        
        # 计算点积
        dot_product = sum(a * b for a, b in zip(vec1, vec2))
        # 计算模长
        mag1 = math.sqrt(sum(a**2 for a in vec1))
        mag2 = math.sqrt(sum(b**2 for b in vec2))
        # 避免除零错误
        if mag1 * mag2 == 0:
            return 0.0
        # 计算余弦相似度
        similarity = dot_product / (mag1 * mag2)
        # 转换为百分比并保留两位小数
        return round(similarity * 100, 2)


    ### 辅助函数：查找相似段落
    def find_similar_sections(self,text1, text2, window_size=200):
        """查找两篇文章中的相似段落（简化版）"""
        if not text1 or not text2:
            return []
        
        similar_sections = []
        # 将文本分割成段落
        paragraphs1 = re.split(r'\n|\。|\！|\？|\.|!|\?', text1)
        paragraphs2 = re.split(r'\n|\。|\！|\？|\.|!|\?', text2)
        
        for para1 in paragraphs1:
            if len(para1) < 50:  # 跳过太短的段落
                continue
            for para2 in paragraphs2:
                if len(para2) < 50:
                    continue
                # 预处理段落
                proc_para1 = preprocess_text(para1)
                proc_para2 = preprocess_text(para2)
                # 计算段落相似度
                para_sim = calculate_similarity(proc_para1, proc_para2)
                # 如果相似度超过阈值，记录相似段落
                if para_sim > 30:  # 相似度阈值
                    similar_sections.append({
                        'paper_para': para1[:window_size] + '...',
                        'article_para': para2[:window_size] + '...',
                        'similarity': round(para_sim, 2)
                    })
                    # 为避免重复匹配，找到一个相似段落后跳出循环
                    break
        
        # 按相似度降序排序
        similar_sections.sort(key=lambda x: x['similarity'], reverse=True)
        return similar_sections[:5]  # 返回前5个最相似的段落
#---------------------------------------------------------------------



    
    def get_paper(self, paper_id):
        """获取单个论文信息"""
        paper = self.paper_dao.get_paper_by_id(paper_id)
        
        if not paper:
            return {
                'code': 404,
                'message': '论文不存在'
            }
        
        return {
            'code': 200,
            'message': '获取成功',
            'data': paper.to_dict()
        }
    
    def get_user_papers(self, user_id, page=1, per_page=10):
        """获取用户的所有论文"""
        # 检查用户是否存在
        from backend.models.user import User
        user = User.query.get(user_id)
        if not user:
            return {
                'code': 404,
                'message': '用户不存在'
            }
        
        papers = self.paper_dao.get_papers_by_author(user_id)
        
        return {
            'code': 200,
            'message': '获取成功',
            'data': {
                'user_info': {
                    'user_id': user.id,
                    'username': user.username
                },
                'papers': [paper.to_dict() for paper in papers]
            }
        }

    def generate_file_path(self, original_filename):
        """生成简单的唯一文件路径（无日期）"""
        # 确保文件名安全
        filename = secure_filename(original_filename)
        ext = os.path.splitext(filename)[1].lower()
        
        # 生成唯一文件名
        unique_filename = f"{uuid.uuid4().hex}{ext}"
        file_path = os.path.join("papers", unique_filename)  # 存储相对路径
        full_path = os.path.join(self.upload_folder, unique_filename)  # 完整物理路径

        return file_path, full_path
    def upload_paper(self, title, author_id, file):
        """上传逻辑（不保存文件，仅提取内容）"""
        try:
            logger.info(f"开始上传文件: {file.filename}")
            
            # 安全检查文件名
            filename = secure_filename(file.filename)
            #if not Paper.is_allowed_file(filename):
            #    raise ValueError("11111111111111111不支持的文件类型")
                
            # 不保存文件，file_path 设为 None
            file_path = None
            # 尝试提取内容（如果文件类型支持）
            content = None
            if filename.endswith(('.txt', '.pdf', '.docx')):
                # 读取文件内容但不保存
                content_bytes = file.stream.read()
                file.stream.seek(0)  # 重置文件指针
                
                # 将字节转换为字符串（假设文本文件为 UTF-8 编码）
                if filename.endswith('.txt'):
                    try:
                        content = content_bytes.decode('utf-8')
                    except UnicodeDecodeError:
                        # 尝试其他编码
                        content = content_bytes.decode('gbk', errors='ignore')
                else:
                    # 对于 PDF/DOCX，使用提取器（需要安装相应库）
                    content = Paper.extract_content(content_bytes, filename)

            logger.info("win")
            # 创建论文记录
            new_paper = Paper(
                title=title,
                author_id=author_id,
                file_path=file_path,  # None
                content=content
            )
            
            #保存到数据库
            self.paper_dao.create_paper(new_paper)
            logger.info(f"论文上传成功 - ID: {new_paper.id}")
            return new_paper
            
        except Exception as e:
            logger.error(f"上传失败: {str(e)}")
            raise


    def delete_paper(self, paper_id):
        """删除论文"""
        success, message = self.paper_dao.delete_paper(paper_id)

        #计入操作记录
        Operation.log_operation(
            user_id=self.paper.author_id,
            paper_id=paper_id,
            operation_type="删除论文",
            file_name="self.paper.title"
        )
        if not success:
            return {
                'code': 400,
                'message': message
            }
        
        return {
            'code': 200,
            'message': message
        }
    
    def check_spelling(self, file):
        """论文错字检测（直接处理文件）"""
        try:
            # 1. 检查文件是否有效
            if not file or not file.filename:
                return False, '未提供有效文件'
            
            # 2. 解析文件内容
            file_ext = file.filename.split('.')[-1].lower()
            content = self._extract_file_content(file, file_ext)
            
            if not content:
                return False, '文件内容为空或无法解析'
            
            # 3. 执行错字检测
            typo_results = self._detect_typos(content)
            
            return True, {
                'total_typos': len(typo_results),
                'typo_details': typo_results,
                'content_length': len(content)
            }
            
        except Exception as e:
            return False, f'错字检测失败: {str(e)}'

    def _detect_typos(self, content):
        """执行错字检测算法"""
        typo_results = []
        
        # 1. 简单的错字检测（基于预设字典）
        for match in self.typo_pattern.finditer(content):
            word = match.group(0)
            # 检查是否存在于错字对中
            for correct_words, typo_map in self.typo_dict.items():
                if word in typo_map:
                    typo_results.append({
                        'position': match.start(),
                        'wrong_word': word,
                        'suggestions': [w for w in correct_words if w != word],
                        'context': self._get_context(content, match.start(), 20)  # 前后20个字符的上下文
                    })
        
        # 2. 可扩展其他错字检测规则（如：常见拼写错误、异形词等）
        # ...
        
        return typo_results

    def _get_context(self, content, position, length):
        """获取错字位置的上下文"""
        start = max(0, position - length)
        end = min(len(content), position + length)
        return content[start:end]

    def check_plagiarism(self, file, num_articles=5):
        """
        论文查重：从上传文件获取论文内容，爬取多篇主题相似文章，计算综合相似度
        file: 上传的论文文件对象
        num_articles: 爬取的相似文章数量(默认5篇)
        """
        logger.info("begin service check_plagiarism")
        
        # 1. 解析上传的文件获取论文内容
        try:
            # 检查文件类型
            logger.info("begin 1")
            filename = file.filename
            if not filename:
                return {
                    'code': 400,
                    'message': '未上传有效文件',
                    'data': None
                }
            
            # 根据文件扩展名处理不同类型的文件
            file_ext = filename.split('.')[-1].lower()
            
            if file_ext == 'txt':
                # 文本文件直接读取
                paper_content = file.read().decode('utf-8')
            elif file_ext == 'pdf':
                # PDF文件解析
                # 这里需要使用PDF解析库，如PyPDF2、pdfplumber等
                # 示例代码（需要安装相应库）：
                import pdfplumber
                with pdfplumber.open(file) as pdf:
                    paper_content = ""
                    for page in pdf.pages:
                        paper_content += page.extract_text()
            elif file_ext in ['docx', 'doc']:
                # Word文件解析
                # 需要使用python-docx库
                # 示例代码（需要安装相应库）：
                from docx import Document
                doc = Document(file)
                paper_content = "\n".join([para.text for para in doc.paragraphs])
            else:
                return {
                    'code': 400,
                    'message': f'不支持的文件类型: {file_ext}，请上传txt、pdf或docx文件',
                    'data': None
                }
            
            # 获取论文标题（从文件名或文件内容提取）
            paper_title = filename.rsplit('.', 1)[0]  # 默认使用文件名作为标题
            
            if not paper_content.strip():
                return {
                    'code': 400,
                    'message': '论文内容为空，无法查重',
                    'data': None
                }
                
        except Exception as e:
            return {
                'code': 500,
                'message': f'文件解析失败: {str(e)}',
                'data': None
            }
        
        try:
            # 2. 提取论文主题关键词
            logger.info("begin 2")
            keywords = self.extract_keywords(paper_content)
            if not keywords:
                return {
                    'code': 400,
                    'message': '无法提取主题关键词',
                    'data': None
                }
            
            # 3. 同步爬取多篇维普网相似文章
            logger.info("begin 3: 爬取维普网相似文章")
            similar_articles = self.crawl_multiple_articles(keywords, num_articles)
            if not similar_articles:
                return {
                    'code': 400,
                    'message': '未找到维普网相似文章，无法查重',
                    'data': None
                }
            
            # 4. 文本预处理
            logger.info("begin 4")
            processed_paper = self.preprocess_text(paper_content)
            
            # 5. 计算与每篇文章的相似度
            logger.info("begin 5")
            comparison_results = []
            all_similar_sections = []
            
            for article in similar_articles:
                article_content = article.get('content', '')
                if not article_content:
                    continue
                    
                processed_article = self.preprocess_text(article_content)
                similarity = self.calculate_similarity(processed_paper, processed_article)
                
                # 查找相似段落
                similar_sections = self.find_similar_sections(paper_content, article_content)
                all_similar_sections.extend(similar_sections)
                
                comparison_results.append({
                    'article_title': article.get('title', '未知'),
                    'similarity_rate': similarity,
                    'url': article.get('url', '')
                })
            
            # 6. 计算综合相似度（加权平均）
            logger.info("begin 6")
            if comparison_results:
                total_similarity = sum(res['similarity_rate'] for res in comparison_results)
                avg_similarity = total_similarity / len(comparison_results)
            else:
                avg_similarity = 0
            
            # 7. 生成结果（按相似度降序排列）
            logger.info("begin 7")
            comparison_results.sort(key=lambda x: x['similarity_rate'], reverse=True)
            all_similar_sections.sort(key=lambda x: x['similarity'], reverse=True)
            
            result = {
                'comprehensive_similarity': round(avg_similarity, 2),
                'paper_title': paper_title,
                'comparison_results': comparison_results,
                'most_similar_sections': all_similar_sections[:5],
                'keywords': keywords,
                'num_articles': len(similar_articles)
            }
            
            return {
                'code': 200,
                'message': '查重完成',
                'data': result
            }
            
        except Exception as e:
            return {
                'code': 500,
                'message': f'查重过程出错：{str(e)}',
                'data': None
            }
        
    def extract_theme(self, file):
        """论文主题提取（直接接收文件）"""
        try:
            logger.info("begin  find theme")
            # 1. 检查文件是否有效
            if not file or not file.filename:
                return {
                    'code': 400,
                    'message': '未上传有效文件'
                }
            
            # 2. 解析文件获取内容
            filename = file.filename
            file_ext = filename.split('.')[-1].lower()
            paper_content = self._extract_file_content(file, file_ext)
            
            if not paper_content:
                return {
                    'code': 400,
                    'message': '文件内容为空，无法提取主题'
                }
            
            # 3. 文本预处理
            processed_text = self.preprocess_text(paper_content)
            
            # 4. 提取关键词
            keywords = self.extract_keywords(paper_content, top_n=5)
            if not keywords:
                return {
                    'code': 400,
                    'message': '无法提取主题关键词'
                }
            
            # 5. 统计词频，获取高频词
            word_counts = Counter(processed_text)
            top_words = word_counts.most_common(20)  # 取前20个高频词
            
            # 6. 生成主题摘要
            theme_summary = self._generate_theme_summary(paper_content, keywords, top_words)
            
            # 7. 构建返回结果（从文件名获取标题）
            paper_title = filename.rsplit('.', 1)[0]  # 使用文件名作为标题
            logger.info(f"end  find theme11111111{theme_summary}")
            result = {
                'title': paper_title,
                'keywords': keywords,
                'top_words': top_words,
                'summary': theme_summary,
                'word_frequency': dict(word_counts),
                'filename': filename
            }
            logger.info(f"end  find theme{theme_summary}")
            return {
                'code': 200,
                'message': '主题提取完成',
                'data': result
            }
            
        except Exception as e:
            current_app.logger.error(f'主题提取错误: {str(e)}')
            return {
                'code': 500,
                'message': f'主题提取失败: {str(e)}'
            }

    def _extract_file_content(self, file, file_ext):
        """从文件对象中提取内容（支持多种格式）"""
        try:
            # 读取文件字节数据
            file_bytes = file.read()
            
            if file_ext == 'txt':
                # 文本文件直接解码
                return file_bytes.decode('utf-8', errors='ignore')
            
            elif file_ext == 'pdf':
                # PDF文件解析（需要pdfplumber库）
                import pdfplumber
                with pdfplumber.open(io.BytesIO(file_bytes)) as pdf:
                    return ''.join([page.extract_text() or '' for page in pdf.pages])
            
            elif file_ext == 'docx':
                # DOCX文件解析（基于XML的ZIP格式）
                from docx import Document
                doc = Document(io.BytesIO(file_bytes))
                return '\n'.join([para.text for para in doc.paragraphs])
        
            elif file_ext == 'doc':
                # DOC文件解析（二进制格式）
                import textract  # 需要安装textract库
                text = textract.process(io.BytesIO(file_bytes), extension='doc')
                return text.decode('utf-8', errors='ignore')
        
            else:
                # 不支持的文件格式
                current_app.logger.warning(f'不支持的文件格式: {file_ext}')
                return None
                
        except Exception as e:
            current_app.logger.error(f'文件解析错误: {str(e)}')
            return None


    def _generate_theme_summary(self, text, keywords, top_words, summary_length=500):
        """生成主题摘要"""
        # 1. 按句号、问号、感叹号分割段落
        logger.info("begin theme summary")
        paragraphs = re.split(r'(。|！|\?|\.|!|\?)', text)
        # 合并分割的标点符号和内容
        full_paragraphs = []
        for i in range(0, len(paragraphs), 2):
            if i + 1 < len(paragraphs):
                full_paragraphs.append(paragraphs[i] + paragraphs[i+1])
            else:
                full_paragraphs.append(paragraphs[i])
        
        # 2. 计算每个段落与关键词的相关度
        paragraph_scores = []
        for para in full_paragraphs:
            score = 0
            # 关键词出现次数越多，分数越高
            for keyword in keywords:
                score += para.count(keyword)
            # 高频词出现次数越多，分数越高
            for word, _ in top_words:
                score += para.count(word)
            paragraph_scores.append((para, score))
        
        # 3. 按分数排序，选择分数最高的段落作为摘要基础
        paragraph_scores.sort(key=lambda x: x[1], reverse=True)
        if not paragraph_scores:
            return "无法生成主题摘要"
        
        # 4. 截取前N个高分段落，合并为摘要
        selected_paragraphs = []
        current_length = 0
        for para, _ in paragraph_scores:
            para_length = len(para)
            if current_length + para_length <= summary_length:
                selected_paragraphs.append(para)
                current_length += para_length
            else:
                break
        
        # 5. 拼接摘要并处理长度
        summary = ''.join(selected_paragraphs)
        if len(summary) > summary_length:
            summary = summary[:summary_length] + '...'
        logger.error(f"end theme111111111 summary{summary!r}")
        return summary

